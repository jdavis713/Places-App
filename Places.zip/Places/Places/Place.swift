//
//  Place.swift
//  Places
//
//  Created by Jordan Davis on 4/24/19.
//  Copyright © 2019 Jordan Davis. All rights reserved.
//

import Foundation

struct Place {
    
    // name
    // location (lat, long)
    //SET UP properties for name and location (location wil include lat and long), then INIT
    //This allows the text fields to have information inputted into them
    
    let name: String
    let location: (latitude: Double, longitude: Double)
    
    init(name: String, latitude: Double, longitude: Double) {
        self.name = name
        self.location = (latitude: latitude, longitude: longitude)
    }
    
    
    
}
