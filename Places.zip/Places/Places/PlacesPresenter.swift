//
//  PlacesPresenter.swift
//  Places
//
//  Created by Jordan Davis on 4/24/19.
//  Copyright © 2019 Jordan Davis. All rights reserved.
//PROTOCOL , defines how we can interact with something

import Foundation

protocol PlacesPresenter: AnyObject {
    
    var placeController: PlaceController? { set get }
}

// with this, we can get the view controllers to conform to this
