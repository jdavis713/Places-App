//
//  PlacesTableViewController.swift
//  Places
//
//  Created by Jordan Davis on 4/24/19.
//  Copyright © 2019 Jordan Davis. All rights reserved.
//The information has been shared and passed via UI, now we have to do it via Code

import UIKit

protocol PlaceSelectionDelegate: AnyObject {
    func placeWasSelected(place: Place)
}

class PlacesTableViewController: UITableViewController, PlacesPresenter {
    
    var placeController: PlaceController?
    weak var delegate: PlaceSelectionDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
   // This refreshes list data
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        tableView.reloadData()
    }

    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return placeController?.places.count ?? 0
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlaceCell", for: indexPath)

        // get place for row index
        let place = placeController?.places[indexPath.row]
        
        cell.textLabel?.text = place?.name

        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        guard let place = placeController?.places[indexPath.row] else { return }
        
        delegate?.placeWasSelected(place: place)
    }
    
}
