//
//  CreateNewPlaceViewController.swift
//  Places
//
//  Created by Jordan Davis on 4/24/19.
//  Copyright © 2019 Jordan Davis. All rights reserved.
//

import UIKit

class CreateNewPlaceViewController: UIViewController, PlacesPresenter {
    var placeController: PlaceController? //This passes information to my 'add places' VC
    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var latitudeTextField: UITextField!
    @IBOutlet weak var longitudeTextField: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()


    }
    
    @IBAction func savePlaceButtonPressed(_ sender: Any) {
        // print("Save") instead, I need to grab the text, see func below
        
        guard let name = locationTextField.text,
        let latitudeString = latitudeTextField.text,
        let latitude = Double(latitudeString),
        let longitudeString = longitudeTextField.text,
        let longitude = Double(longitudeString)
        else { return }
        
        placeController?.createPlace(with: name, latitude: latitude, longitude: longitude)
        //this pulls the name and lat&long out of the text field. coordinates have to be converted from strings to doubles
    }

}
