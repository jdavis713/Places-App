//
//  VisitedPlacesViewController.swift
//  Places
//
//  Created by Jordan Davis on 4/24/19.
//  Copyright © 2019 Jordan Davis. All rights reserved.
// THIS IS THE View CONTROLLER FOR THE LOCATIONS UNDER MY MAP

import UIKit

class VisitedPlacesViewController: UIViewController, PlacesPresenter {
    var placeController: PlaceController? //This was shared with CreateNewPlacesVC (Add places SB)
    
    var mapViewController: MapViewController?
    var placesTableViewController: PlacesTableViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "PlacesTable" {
            // get a places table view controller
            guard let placesTVC = segue.destination as? PlacesTableViewController else { return }
            
            // set the place controller
            placesTVC.placeController = placeController
            placesTVC.delegate = self
            placesTableViewController = placesTVC
        } else if segue.identifier == "MapView" {
            // get map view controller
            guard let mapVC = segue.destination as? MapViewController else { return }
            
            mapViewController = mapVC
        }
    }


}

extension VisitedPlacesViewController: PlaceSelectionDelegate {
    func placeWasSelected(place: Place) {
        // pass the location to the map controller
        mapViewController?.location = place.location
    }
}
