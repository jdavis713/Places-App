//
//  PlacesTabBarViewController.swift
//  Places
//
//  Created by Jordan Davis on 4/24/19.
//  Copyright © 2019 Jordan Davis. All rights reserved.
//

import UIKit

class PlacesTabBarViewController: UITabBarController {

    let placeController = PlaceController() //next, we have to pass this info between both screens a protocol needs to be established (Create new places & Visited places)
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Pass the placeController to the child view controllers
        //i.e. share data between all the managged screens (a for loop is needed)
        
        for childViewController in children {
            //"children" in this case are the "add places" and "Places" tabs and VCs
            if let childViewController = childViewController as?
                PlacesPresenter {
                childViewController.placeController = placeController
            }
        }
    }
    


}
