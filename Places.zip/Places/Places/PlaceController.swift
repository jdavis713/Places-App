//
//  PlaceController.swift
//  Places
//
//  Created by Jordan Davis on 4/24/19.
//  Copyright © 2019 Jordan Davis. All rights reserved.
//THIS IS A MODEL CONTROLLER, WILL ALLOW ME TO CONTROL MULTIPLE PLACES

import Foundation

class PlaceController {
    
    var places: [Place] = [] //[Place]() **This also calls for the array. Just a different syntax**
    
    init() {
        // Test data
        createPlace(with: "Rochester, NY", latitude: 43.1, longitude: -77.6)
        createPlace(with: "San Francisco, CA", latitude: 37.7, longitude: -122.4)
    }
    
    func createPlace(with name: String, latitude: Double, longitude: Double) {
        let place = Place(name: name, latitude: latitude, longitude: longitude)
        
        places.append(place)
    }
}
//This is the array that allows me to input new places. Use an empty array.
